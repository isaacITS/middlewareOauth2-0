﻿using Microsoft.AspNetCore.Mvc;

using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using API_MIDDLEWARE.Models.Entities; 

namespace API_MIDDLEWARE.Controllers
{
    public class FirebaseController : ControllerBase
    {
        IFirebaseClient cliente;

        public FirebaseController()
        {
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "riUaV9dyq1ck66xoHB250lfUmxPvG59Y3zBb5lUs",
                BasePath = "https://middlewareoauth20-default-rtdb.firebaseio.com/"
            };

            cliente = new FirebaseClient(config);

        }


        [HttpPost("Crear U Firebase")]
        public ActionResult Crear(UsuarioFirebase usuarioF)
        {
            string idGenerado = Guid.NewGuid().ToString("N");
            SetResponse response = cliente.Set("Usuarios/" + idGenerado, usuarioF);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return Ok();
            }
            else
            {
                return Ok();
            }


        }
        public IActionResult Index()
        {
            return Ok();
        }
    }
}
