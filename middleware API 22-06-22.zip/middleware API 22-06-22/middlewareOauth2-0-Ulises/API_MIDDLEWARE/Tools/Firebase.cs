﻿namespace API_MIDDLEWARE.Tools
{
    public class Firebase
    {
    }
}
